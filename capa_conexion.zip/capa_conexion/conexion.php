<?php

class conectar {

    public function conexion() {
     $servername = "localhost";
		$database = "onechann_bdsnewsistema";
       $username = "onechann_soledad";
        $password = "One2021..";
        $conexion = mysqli_connect($servername, $username, $password, $database);
        return $conexion;
    }
}

