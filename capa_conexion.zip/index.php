<?php
header('Location: /OCH/vista/login.php');
?>